// window.addEventListener("scroll", () => {
//     const scrollPosition = window.scrollY;
//     const body = document.body;

//     if (scrollPosition > 100) {
//         body.style.backgroundColor = "lightblue"; // Change background color
//     } else {
//         body.style.backgroundColor = "white"; // Reset background color
//     }
// });